# virtual-assistant
Đây là source code của Youtube video "Lập trình Trợ lý ảo Tiếng Việt bằng JavaScript"

Để chạy được ứng dụng, các bạn hãy sử dụng Extension Live Server của Visual Studio Code rồi chuột phải lên file index.html chọn "Open with Live Server"
